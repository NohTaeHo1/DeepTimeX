!! 그래도 돌리면 너무 오래 걸리므로 train.py 에서 epoch 바꾸고 테스트해봄

10epoch 35분 걸림

mlp 0.5초
fcn 43ch
cnn 2초
resnet 35초